
import javax.swing.JFrame;
import javax.swing.WindowConstants;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Andrei
 */
public class MainFrame extends JFrame {
    public void init() {
    }
//    public static void main(String[] args) {
//        
//    Book[] bookArray = new Book[20];   
//            
//    String[] bookArrayList = {"Atomic Habits", "Diary of a Wimpy Kid", 
//    "The Subtle Art of Not Giving a F*ck", "Lord of the Rings: The Fellowship of The Ring", "A Secret Between Gentlemen", "The Hobbit", "Ikigai", "The Power of Habit",
//    "Rich Dad Poor Dad", "The Willoughbys", "The Fault in our Stars", "milk and honey", "the sun and her flowers", "It Ends With Us", "Reminders of Him", "Theodore Boone: The Activist",
//    "Area 51 Interns: Alien Summer #1", "The Martian", "Catching Fire", "Harry Potter and the Deathly Hallows"};
//    
//    double[] bookrentPriceList = {3, 3, 5, 10, 5, 3, 3, 5, 10, 5, 3, 3, 5, 10, 5, 3, 3, 5, 10, 5,};
//    double[] bookbuyPriceList = {29.99, 24.99, 34.99, 14.99, 34.99, 12.50, 5.99, 9.99, 14.99, 10.00, 24.80, 34.99, 5.99, 7.80, 12.99, 9.99, 11.30, 34.99, 14.99, 34.99,};
//
//    for(int i = 0; i < 20; i++) {
//        bookArray[i].setBookTitle(bookArrayList[i]);
//        bookArray[i].setBuyPrice(bookbuyPriceList[i]);
//        bookArray[i].setRentPrice(bookrentPriceList[i]);
//    }

}
